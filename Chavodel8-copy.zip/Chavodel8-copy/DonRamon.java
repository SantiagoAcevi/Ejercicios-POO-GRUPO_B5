

public class DonRamon extends Personaje
{
    
    public DonRamon(String nombre, int edad, String personalidad, String rol){
     super(nombre, edad, personalidad, rol);
 }
 
 public void golpearChavo(){
     System.out.println("Don Ramon procede a golpear al Chavo del 8");
 }
 public void pisotearGorra(){
     System.out.println("Don Ramon se enfurece y ocasiona que se quite la gorra para depues pisotearla");

 }
 
}