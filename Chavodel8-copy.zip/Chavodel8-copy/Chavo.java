

public class Chavo extends Personaje
{
    
    public Chavo(String nombre, int edad, String personalidad, String rol){
     super(nombre, edad, personalidad, rol);
 }
 
 public void comerTorta(){
     System.out.println("El Chavo se come una torta de Jamon");
 }
 public void pegarHombreBarriga(){
    System.out.println("El Chavo golpea al señor Barriga sin querer queriendo");

 }
}