

public class Quico extends Personaje
{
     public Quico(String nombre, int edad, String personalidad, String rol){
     super(nombre, edad, personalidad, rol);
 }
 
 public void llorarPared(){
     System.out.println("Quico se pone triste y procede a llorar junto a una pared");
 }
 public void llamaMama(){
    System.out.println("Quico llama a su mamá");

 }
}