
public class Jugador
{
   private String nombre;
   private String id;
   private int edad;
   
   public Jugador(String nombre, String id, int edad){
       this.nombre=nombre;
       this.id=id;
       this.edad=edad;
   }
   
   //métodos getters
   public String getNombre(){
       return this.nombre;
   }
   public String getId(){
       return this.id;
   }
   public int getEdad(){
       return this.edad;
   }
   
   //métodos setters
   public void setNombre(String nombre){
       this.nombre=nombre;
   }
   public void setId(String id){
       this.id=id;
   }
   public void setEdad(int edad){
       this.edad=edad;
   }
   //métodos operacionales
   public void controlarPersonaje(Personaje clase){
       System.out.println("Ahora controlas al personaje "+clase.getNombre());
   }
   
   
}