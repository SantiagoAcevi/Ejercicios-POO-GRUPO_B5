

public class Profesor extends Personaje
{
    
 public Profesor(String nombre, int edad, String personalidad, String rol){
     super(nombre, edad, personalidad, rol);
 }
 
 public void comprarFlores(){
     System.out.println("El profesor Jirafales compra un ramo de rosas");
 }
 public void besarFlorinda(){
    System.out.println("El profesor Jirafales besa a Doña Florinda");

 }
}