

public class DoñaFlorinda extends Personaje
{
    public DoñaFlorinda(String nombre, int edad, String personalidad, String rol){
     super(nombre, edad, personalidad, rol);
 }
public void golpearRamon(){
    System.out.println("Doña Florinda procede a golpear al vecino Don Ramon por supuestamente molestar a quico");
}
public void besarProfesor(){
    System.out.println("Doña Florinda procede a besar al profesor Jirafales ");

}
}