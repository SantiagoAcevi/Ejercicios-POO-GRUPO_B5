

public class Chilindrina extends Personaje
{
   public Chilindrina(String nombre, int edad, String personalidad, String rol){
     super(nombre, edad, personalidad, rol);
 }
 
 public void llorarComoLoca(){
     System.out.println("Comienza a llorar y a gritar mucho");
 }
 public void CulparPersonaje(Personaje clase){
     System.out.println("Le echa la culpa a "+clase.getNombre());
 }
}