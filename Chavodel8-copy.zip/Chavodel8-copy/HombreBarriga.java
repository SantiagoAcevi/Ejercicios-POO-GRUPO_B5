

public class HombreBarriga extends Personaje
{
    public HombreBarriga(String nombre, int edad, String personalidad, String rol){
     super(nombre, edad, personalidad, rol);
 }
 public void reprenderChavo(){
     System.out.println("El señor Barriga se enoja con el chavo y lo regaña ");
 }
 public void cobrarRenta(){
     System.out.println("El señor Barriga procede a cobrar la renta a cada uno de los arrendatarios");
 }
}