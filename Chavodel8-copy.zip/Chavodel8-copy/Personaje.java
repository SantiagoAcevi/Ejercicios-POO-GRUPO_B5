import javax.swing.JOptionPane;
import java.util.List;
import java.util.ArrayList;

public abstract class Personaje
{
    protected String nombre;
    protected int edad;
    protected String personalidad;
    protected String rol;
    
    public Personaje(String nombre, int edad, String personalidad, String rol){
        this.nombre=nombre;
        this.edad=edad;
        this.personalidad=personalidad;
        this.rol=rol;
    }
    
    //metodos getters
    public String getNombre(){
        return this.nombre; 
    }
    public int getEdad(){
        return this.edad;
    }
    public String getPersonalidad(){
        return this.personalidad;
    }
    public String getRol(){
        return this.rol;
    }
    //setters
    public void setNombre(String nombre){
        this.nombre=nombre; 
    }
    public void setEdad(int edad){
        this.edad=edad;
    }
    public void setPersonalidad(String personalidad){
        this.personalidad=personalidad;
    }
    public void setRol(String rol){
        this.rol=rol;
    }
    //metodos operacionales
    public void interactuarPersonaje(Personaje clase){
        System.out.println("Ahora estas conversando con "+clase.getNombre());
    }
    
    public Vecindad moverseVecindad(Vecindad actual, List<Vecindad> listaVecindades){
        System.out.println("El personaje se encuentra en "+actual.getNombre());
        String movimiento=JOptionPane.showInputDialog("¿A donde desea moverse");
        
        for(Vecindad elemento: listaVecindades){
            if(elemento.getNombre().equalsIgnoreCase(movimiento)){
            System.out.println("Te moviste a: "+elemento.getNombre());
            return elemento;
            }
            
        }
        System.out.println("No se encuentra el sitio donde desea llegar ir");
        return actual;
        

    }
    public void interactuarObjeto(List<Objeto> listaObjeto){
        
        String elegido= JOptionPane.showInputDialog("¿Con cual objeto desea interactuar?");
        for(Objeto elemento: listaObjeto){
            if(elemento.getNombre().equalsIgnoreCase(elegido)){
            JOptionPane.showMessageDialog(null,"Encontraste el objeto","Felicidades",JOptionPane.INFORMATION_MESSAGE);
            String accion=JOptionPane.showInputDialog("¿Que deseas hacer con el objeto?");
            System.out.println("Decidiste "+accion+" el objeto "+elemento.getNombre());
            return;
            }
        }
        System.out.println("no se encuentra el objeto que buscas");
    }
    
}