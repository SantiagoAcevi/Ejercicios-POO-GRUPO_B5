import java.util.List;
import java.util.ArrayList;

public class Objeto
{
    private String nombre;
    private String descripcion;
    
    public Objeto(String nombre,String descripcion ){
        this.nombre=nombre;
        this.descripcion=descripcion;
    }
    
    //métodos getters
    public String getNombre(){
        return this.nombre;
    }
    public String getDescripcion(){
        return this.descripcion;
    }
    //métodos setters
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setDescripcion(String descripcion){
        this.descripcion=descripcion;
    }    
}