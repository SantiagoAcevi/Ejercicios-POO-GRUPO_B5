
public abstract class Candidato
{
   protected String nombre;
   protected String apellido;
   protected Grado grado;
   protected String grupo;
   protected String lema;
   protected int numTarjeton;
   protected int votosAfavor;
   
   public Candidato(String nombre, String apellido, Grado grado, String grupo, String lema, int numTarjeton, int votosAfavor){
   this.nombre=nombre;
   this.apellido=apellido;
   this.grado=grado;
   this.grupo=grupo;
   this.lema=lema;
   this.numTarjeton=numTarjeton;
   this.votosAfavor=votosAfavor;
        
   }
   //metodos getters
   public String getNombre(){
       return this.nombre;
   }
   public String getApellido(){
       return this.apellido;
   }
   public Grado getGrado(){
       return this.grado;
   }
   public String getGrupo(){
       return this.grupo;
   }
   public String getLema(){
       return this.lema;
   }
   public int getNumTarjeton(){
       return this.numTarjeton;
   }
   public int getVotosAfavor(){
       return this.votosAfavor;
   }
   
   //metodos setters
   public void setNombre(String nombre){
       this.nombre=nombre;
   }
   public void setApellido(String apellido){
       this.apellido=apellido;
   }
   public void setGrado(Grado grado){
       this.grado=grado;
   }
   public void setGrupo(String grupo){
       this.grupo=grupo;
   }
   public void setLema(String lema){
       this.lema=lema;
   }
   public void setNumTarjeton(int numTarjeton){
       this.numTarjeton=numTarjeton;
   }
   public void setVotosAfavor(int votosAfavor){
       this.votosAfavor=votosAfavor;
   }
   
   //métodos operacionales
   public int mostrarVotos(){
       
       return votosAfavor;
   }
   
}