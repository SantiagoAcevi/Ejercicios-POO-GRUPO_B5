

public class Estudiante
{
    private String nombre;
    private int edad;
    
    public Estudiante(String nombre, int edad){
        this.nombre=nombre;
        this.edad=edad;
    }
    
    //metodos getters
    public String getNombre(){
        return this.nombre;
    }
    public int getEdad(){
        return this.edad;
    }
    //métodos setters
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public void setEdad(int edad){
        this.edad=edad;
    }
    
    
    
    
}