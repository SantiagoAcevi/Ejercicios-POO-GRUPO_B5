

public class Mascota
{
   private String id;
   private String nombre;
   private String genero;
   private int edad;
   private String cualidades;
   private Tipo tipo;
   
   public Mascota(String id, String nombre, String genero, int edad, String cualidades,Tipo tipo){
       this.id=id;
       this.nombre=nombre;
       this.genero=genero;
       this.edad=edad;
       this.cualidades=cualidades;
       this.tipo=tipo;
   }
   
   //métodos getters
   public String getId(){
       return this.id;
   }
   public String getNombre(){
       return this.nombre;
   }
   public String getGenero(){
       return this.genero;
   }
   public int getEdad(){
       return this.edad;
   }
   public String getCualidades(){
       return this.cualidades;
   }
   public Tipo getTipo(){
       return this.tipo;
   }
   
   //métodos setters
   public void setId(String id){
       this.id=id;
   }
   public void setNombre(String nombre){
       this.nombre=nombre;
   }
   public void setGenero(String genero){
       this.genero=genero;
   }
   public void setEdad(int edad){
       this.edad=edad;
   }
   public void setCualidades(String cualidades){
       this.cualidades=cualidades;
   }
   public void setTipo(Tipo tipo){
       this.tipo=tipo;
   }
   
   
   
}