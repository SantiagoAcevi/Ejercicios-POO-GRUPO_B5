
public class Representante extends Candidato
{
    private Estudiante formula;
    
    public Representante(Estudiante formula,String nombre, String apellido, Grado grado, String grupo, String lema, int numTarjeton, int votosAfavor){
        super(nombre,apellido, grado, grupo,lema,  numTarjeton,  votosAfavor);
        this.formula=formula;
    }
    
    //métodos getters
    public Estudiante getFormula(){
        return this.formula;
    }
    //métodos setters
    public void setFormula(Estudiante formula){
        this.formula=formula;
    }
}