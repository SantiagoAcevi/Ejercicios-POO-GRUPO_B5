

public enum Tipo
{
    AEREO, TERRESTRE, ACUATICO
}