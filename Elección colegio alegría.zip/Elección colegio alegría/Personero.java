
public class Personero extends Candidato
{
    private Mascota mascota;
    
    
    public Personero(Mascota mascota, String nombre, String apellido, Grado grado, String grupo, String lema, int numTarjeton, int votosAfavor){
        super(nombre, apellido,grado,grupo, lema, numTarjeton, votosAfavor);
        this.mascota=mascota;
    }
    
    //métodos getters
    public Mascota getMascota(){
        return this.mascota;
    }
    //métodos setters
    public void setMascota(Mascota mascota){
        this.mascota=mascota;
    }
    
    
    
    
    
}