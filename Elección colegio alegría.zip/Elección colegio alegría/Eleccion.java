import java.util.List;
import java.util.ArrayList;
public class Eleccion
{
    private List<Candidato> candidatos;
    private int votosBlanco;
    private int votosNulo;
    
    public Eleccion(List<Candidato> candidatos, int votosBlanco, int votosNulo){
        this.candidatos=candidatos;
        this.votosBlanco=votosBlanco;
        this.votosNulo=votosNulo;
    }
    
    //métodos getters
    public List<Candidato> getCandidatos(){
        return this.candidatos;
    }
    public int getVotosBlanco(){
        return this.votosBlanco;
    }
    public int getVotosNulo(){
        return this.votosNulo;
    }
    
    //métodos setters
    public void setCandidatos(List<Candidato> candidatos){
        this.candidatos=candidatos;
    }
    public void setVotosBlanco(int votosBlanco){
        this.votosBlanco=votosBlanco;
    }
    public void setVotosNulo(int votosNulo){
        this.votosNulo=votosNulo;
    }
    //métodos operacionales
    public Candidato personeroElegidoGanador(List<Candidato> candidatos) {
        if (candidatos == null) {
        return null;
    }
    
    Candidato ganador = candidatos.get(0); // usamos el primer candidato de la lista

    for (Candidato elemento : candidatos) {
        if (elemento.getVotosAfavor() > ganador.getVotosAfavor()) {
            ganador = elemento;
        }
    }

    return ganador;
    } 
    
    public Candidato menorVotacion(List<Candidato> candidatos){
        if (candidatos == null) {
        return null;
    }
        Candidato mas_quemado= candidatos.get(0);// usamos el primer candidato
    for(Candidato elemento: candidatos){
        if(elemento.getVotosAfavor()< mas_quemado.getVotosAfavor()){
            mas_quemado=elemento;
        }
    }
    return mas_quemado;
    }
    
    public int poblacionElectoral(Candidato objeto){
        int suma=votosBlanco+votosNulo+objeto.getVotosAfavor();
        return suma;
        
    }
}