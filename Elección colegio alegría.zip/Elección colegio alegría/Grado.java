

public class Grado
{
    private int numEstudiantes;
    private int year;
    private String grupo;
    
    public Grado(int numEstudiantes, int year, String grupo){
        this.numEstudiantes=numEstudiantes;
        this.year=year;
        this.grupo=grupo;
    }
    //metodos getters
    public int getNumEstudiantes(){
        return this.numEstudiantes;
    }
    public int getYear(){
        return this.year;
    }
    public String getGrupo(){
        return this.grupo;
    }
    //métodos setters
    public void setNumEstudiantes(){
        this.numEstudiantes=numEstudiantes;
    }
    public void setYear(){
        this.year=year;
    }
    public void setGrupo(){
        this.grupo=grupo;
    }
    
    
    
    
}