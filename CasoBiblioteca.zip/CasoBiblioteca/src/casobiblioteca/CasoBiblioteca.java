/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package casobiblioteca;

import controlador.*;
import java.util.ArrayList;
import modelo.*;
import vista.*;

/**
 *
 * @author roca
 */
public class CasoBiblioteca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Usuario> ListaUsuario = new ArrayList<>();
        ArrayList<Prestamo> ListaPrestamo = new ArrayList<>();
        
        
        vistaFormulario frmBiblioteca = new vistaFormulario();

        CntrlUsuario cntrlUsuario = new CntrlUsuario(frmBiblioteca, ListaUsuario);
        CntrlPrestamo cntrlPrestamo = new CntrlPrestamo(frmBiblioteca, ListaUsuario, cntrlUsuario, ListaPrestamo);
        CntrlDevolucion cntrlDevolucion = new CntrlDevolucion(frmBiblioteca, ListaUsuario, ListaPrestamo, cntrlPrestamo);

        cntrlUsuario.setCntrlPrestamo(cntrlPrestamo);
        cntrlUsuario.setCntrlDevolucion(cntrlDevolucion);

        frmBiblioteca.setVisible(true);
        
    }
    
}
