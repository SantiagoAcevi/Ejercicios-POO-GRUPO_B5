/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import modelo.Libro;
import modelo.Prestamo;
import modelo.Usuario;
import vista.*;

/**
 *
 * @author roca
 */
public class CntrlPrestamo implements ActionListener {

    private vistaFormulario frmPrestamo;
    private ArrayList<Usuario> ListaUsuario;
    private ArrayList<Prestamo> listaPrestamo;
    private Libro libro;
    private CntrlUsuario cntrlUsuario;
    private int idPrestamos;

    public CntrlPrestamo() {
    }

    public CntrlPrestamo(vistaFormulario frmPrestamo, ArrayList<Usuario> ListaUsuario, CntrlUsuario cntrlUsuario, ArrayList<Prestamo> listaPrestamo) {
        this.frmPrestamo = frmPrestamo;
        this.ListaUsuario = ListaUsuario;
        this.libro = new Libro();
        this.libro.crearListaLibros();
        this.cntrlUsuario = cntrlUsuario;
        this.idPrestamos = 0;
        this.listaPrestamo = listaPrestamo;

        this.frmPrestamo.btnRPrestamo.addActionListener(this);

        refrescarListaLibros();
    }

    public void refrescarListaLibros() {
        frmPrestamo.comBLibro.removeAllItems();
        for (Libro libro : this.libro.getListaLibros()) {
            if (libro.getCanCopiasHay() != 0) {
                frmPrestamo.comBLibro.addItem(libro);
            }
        }

    }

    public void refrescarListaUsuario() {
        frmPrestamo.comUsuario.removeAllItems();
        for (Usuario usuario : ListaUsuario) {
            frmPrestamo.comUsuario.addItem(usuario);
        }
    }


    public void guardarPrestamo() {
        Usuario usuarioTM = (Usuario) frmPrestamo.comUsuario.getSelectedItem();
        if (usuarioTM != null) {
            if (!usuarioTM.isEsVetado()) {
                Libro libroTM = (Libro) frmPrestamo.comBLibro.getSelectedItem();
                boolean yaPrestamo = false;
                for (Prestamo prestamo : listaPrestamo) {
                    if (prestamo.getUsuario().equals(usuarioTM) && prestamo.getLibro().equals(libroTM)) {
                        yaPrestamo = true;
                        break;
                    }
                }

                if (yaPrestamo) {
                    frmPrestamo.txtAMostrar.setText("El usuario ya realizó un prestrámo de este Libro.");
                } else {
                    if (libroTM.getCanCopiasHay() == 0) {
                        frmPrestamo.txtAMostrar.setText("Ya no hay copias de este libro.");
                    } else {
                        if (frmPrestamo.jDateFechaIngreso.getDate() == null) {
                            frmPrestamo.txtAMostrar.setText("Porfavor, ingrese una fecha.");
                        } else {
                            libroTM.setCanCopiasHay(libroTM.getCanCopiasHay() - 1);
                            Date fechaDate = frmPrestamo.jDateFechaIngreso.getDate();
                            LocalDate fechaIngreso = fechaDate.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();
                            idPrestamos++;
                            String idPrestamoTM = Integer.toString(idPrestamos);
                            switch (idPrestamoTM.length()) {
                                case 1:
                                    idPrestamoTM = "000" + idPrestamoTM;
                                    break;
                                case 2:
                                    idPrestamoTM = "00" + idPrestamoTM;
                                    break;
                                case 3:
                                    idPrestamoTM = "0" + idPrestamoTM;
                                    break;
                                default:
                                    throw new AssertionError();
                            }
                            Prestamo prestamoTM = new Prestamo(idPrestamoTM, usuarioTM, libroTM, fechaIngreso);
                            switch (usuarioTM.getTipoUsuario()) {
                                case ADMINISTRATIVO:
                                    prestamoTM.setFechaDebeDevolver(prestamoTM.getFechaPrestramo().plusDays(3));
                                    break;
                                case PROFESOR:
                                    prestamoTM.setFechaDebeDevolver(prestamoTM.getFechaPrestramo().plusDays(15));
                                    break;
                                case ESTUDIANTE:
                                    prestamoTM.setFechaDebeDevolver(prestamoTM.getFechaPrestramo().plusDays(15));
                                    break;
                                default:
                                    throw new AssertionError();
                            }
                            listaPrestamo.add(prestamoTM);
                            refrescarListaLibros();

                            frmPrestamo.txtAMostrar.setText(""
                                    + "¡Se ha realizado un préstamo! \n"
                                    + "Información del préstamo: \n"
                                    + "Codigo: " + prestamoTM.getId() + "\n"
                                    + "Usuario: " + usuarioTM + "\n"
                                    + "Libro: '" + libroTM.getTitulo() + "' escrito por " + libroTM.getAutor() + "\n"
                                    + "Fecha de préstamo: " + prestamoTM.getFechaPrestramo().toString() + "\n"
                                    + "Fecha máxima que debe ser devuelto el libro: " + prestamoTM.getFechaDebeDevolver().toString() + "\n");
                        }
                    }
                }
            } else {
                frmPrestamo.txtAMostrar.setText(usuarioTM + " está VETADO del sistema de préstamo de libros. Porque no realizó una devolución a su respectivo tiempo.");
            }

        } else {
            frmPrestamo.txtAMostrar.setText("Escoja un usuario, porfavor.");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == frmPrestamo.btnRPrestamo) {
            guardarPrestamo();
        }

    }

}
