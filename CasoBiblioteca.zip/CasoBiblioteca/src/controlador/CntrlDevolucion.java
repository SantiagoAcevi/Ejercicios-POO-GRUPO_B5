/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import modelo.Libro;
import modelo.Prestamo;
import modelo.Usuario;
import vista.*;

/**
 *
 * @author roca
 */
public class CntrlDevolucion implements ActionListener {

    vistaFormulario frmDevolucion;
    ArrayList<Usuario> listaUsuario;
    ArrayList<Prestamo> listaPrestamo;
    CntrlPrestamo cntrlPrestamo;
    boolean haHechoPrestramo;

    public CntrlDevolucion() {
    }

    public CntrlDevolucion(vistaFormulario frmDevolucion, ArrayList<Usuario> listaUsuario, ArrayList<Prestamo> listaPrestamo, CntrlPrestamo cntrlPrestamo) {
        this.frmDevolucion = frmDevolucion;
        this.listaUsuario = listaUsuario;
        this.listaPrestamo = listaPrestamo;
        this.cntrlPrestamo = cntrlPrestamo;
        this.haHechoPrestramo = false;

        this.frmDevolucion.btnDevolver1.addActionListener(this);
        this.frmDevolucion.comBUsuario1.addActionListener(this);
    }

    public void refrescarListaUsuario() {
        frmDevolucion.comBUsuario1.removeAllItems();
        for (Usuario usuario : listaUsuario) {
            frmDevolucion.comBUsuario1.addItem(usuario);
        }
    }

    public void mostrarLibro() {
        haHechoPrestramo = false;
        Usuario usuarioTM = (Usuario) frmDevolucion.comBUsuario1.getSelectedItem();
        frmDevolucion.comBLibroDevolver1.removeAllItems();
        for (Prestamo prestamo : listaPrestamo) {
            if (prestamo.getUsuario().equals(usuarioTM)) {
                frmDevolucion.comBLibroDevolver1.addItem(prestamo.getLibro());
                haHechoPrestramo = true;
            }
        }
    }

    public void devolver() {
        Usuario usuarioTM = (Usuario) frmDevolucion.comBUsuario1.getSelectedItem();
        if (usuarioTM == null) {
            frmDevolucion.txtAResultado1.setText("Escoja un usuario, porfavor.");
        } else {
            if (!haHechoPrestramo) {
                frmDevolucion.txtAResultado1.setText("Este Usuario nunca ha hecho un préstamo.");
            } else {
                Date fechaDate = frmDevolucion.jDateFechaD1.getDate();
                if (fechaDate == null) {
                    frmDevolucion.txtAResultado1.setText("No ha ingresado una fecha. Porfavor, hágalo.");
                } else {
                    double multa = 0;
                    Libro libroTM = (Libro) frmDevolucion.comBLibroDevolver1.getSelectedItem();
                    LocalDate fechaDevolucion = fechaDate.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate();

                    for (Prestamo prestamo : listaPrestamo) {
                        if (prestamo.getUsuario().equals(usuarioTM) && prestamo.getLibro().equals(libroTM)) {
                            multa = prestamo.calcularMulta(fechaDevolucion);
                            prestamo.getLibro().setCanCopiasHay(prestamo.getLibro().getCanCopiasHay() + 1);

                            if (multa == -1) {
                                frmDevolucion.txtAResultado1.setText("La fecha que se escogió es anterior a la fecha del Prestamo (" + prestamo.getFechaPrestramo().toString() + ")");
                            } else if (multa == 0) {
                                frmDevolucion.txtAResultado1.setText(""
                                        + "¡Buenas noticias, " + usuarioTM.getNombre() + "!\n"
                                        + "¡Se ha devuelto '" + libroTM.getTitulo() + "' con éxito!");
                                listaPrestamo.remove(prestamo);
                                mostrarLibro();
                                cntrlPrestamo.refrescarListaLibros();
                            } else {
                                frmDevolucion.txtAResultado1.setText(""
                                        + "¡Malas noticias, " + usuarioTM.getNombre() + "!\n"
                                        + "Se ha entegrado '" + libroTM.getTitulo() + "' después de la fecha acordada\n"
                                        + "Por lo tanto debe pagar una multa de: " + multa);
                                prestamo.getUsuario().setEsVetado(true);
                                listaPrestamo.remove(prestamo);
                                mostrarLibro();
                                cntrlPrestamo.refrescarListaLibros();
                            }
                            break;
                        }
                    }
                }
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmDevolucion.comBUsuario1) {
            mostrarLibro();
        }

        if (e.getSource() == frmDevolucion.btnDevolver1) {
            devolver();
        }
    }

}
