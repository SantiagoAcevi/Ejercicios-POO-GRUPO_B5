/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemanominaacademica;

import controlador.CntrlGestorProyectos;
import controlador.CntrlIngresarEmpleado;
import controlador.CntrlMostrador;
import java.util.ArrayList;
import modelo.Empleado;
import vista.*;

/**
 *
 * @author roca
 */
public class SistemaNominaAcademica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Lista
        ArrayList<Empleado> listaEmpleado = new ArrayList<>();
                       
       vistaFormulario formu=new vistaFormulario();
        
        CntrlMostrador cntrlMostrador = new CntrlMostrador(formu, listaEmpleado);
        CntrlGestorProyectos cntrlGestroProyectos = new CntrlGestorProyectos(formu, formu, listaEmpleado);
        CntrlIngresarEmpleado cntrlIngresarEmpleado = new CntrlIngresarEmpleado(formu, listaEmpleado, cntrlGestroProyectos, cntrlMostrador);
        
        
        formu.setVisible(true);
        
    }
    
}
