
public class Circulo extends Figura_geometrica
{
    private float radio;
    
    public Circulo(String nombre, float radio){
      super(nombre);
      this.radio=radio;
    }

    //métodos getters
    public float getRadio(){
        return this.radio;
    }
    
    //métodos setters
    public void setRadio(float radio){
        this.radio=radio;
    }
    
    //métodos operacionales
    public float calcularArea(){
        float elevacion=(float)Math.pow(this.radio,2);
        return elevacion*PI;
    }
    public float calcularPerimetro(){
        return 2*PI*this.radio;
    }
}