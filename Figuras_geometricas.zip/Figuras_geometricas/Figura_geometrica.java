

public abstract class Figura_geometrica
{
    protected String nombre;
    protected static float PI= 3.1416f;

    public Figura_geometrica(String nombre){
        this.nombre=nombre;
    }
    
    //métodos getters
    public String getNombre(){
        return this.nombre;
    }
    //métodos setters
    public  void setNombre(String nombre){
         this.nombre=nombre;
    }
    //métodos operacionales
    public abstract float calcularArea();
    public abstract float calcularPerimetro();

    
}
