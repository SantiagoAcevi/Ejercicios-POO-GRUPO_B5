
public class Triangulo extends Figura_geometrica
{
    private float base;
    private float altura;
    private float lado1;
    private float lado2;
    private float lado3;
    
    public Triangulo( String nombre, float lado1, float lado2, float lado3){
        super(nombre);
        this.base=base;
        this.altura=altura;
        this.lado1=lado1;
        this.lado2=lado2;
        this.lado3=lado3;
    }
    // métodos getters
    public float getBase(){
        return this.base;
    }
    public float getAltura(){
       return this.altura; 
    }
    public float getLado1(){
        return this.lado1;
    }
    public float getLado2(){
        return this.lado2;
    }
    public float getLado3(){
        return this.lado3;
    }
    
    //métodos setters
    public void setBase(float base){
         this.base=base;
    }
    public void setAltura(float altura){
         this.altura=altura; 
    }
    public void setLado1(float lado1){
         this.lado1=lado1;
    }
    public void setLado2(float lado2){
         this.lado2=lado2;
    }
    public void setLado3(float lado3){
         this.lado3=lado3;
    }
    
    
    //métodos operacionales
    public float calcularArea(){
        return (this.base*this.altura)/2;
    }
    public float calcularPerimetro(){
        return this.lado1+this.lado2+this.lado3;
    }
}
