
public class Cuadrado extends Figura_geometrica
{
  private float lado;
  
  public Cuadrado(float lado, String nombre){
      super(nombre);
      this.lado=lado;
  }
  
  //métodos getters
  public float getLado(){
      return this.lado;
  }
  //métodos setters
  public void setLado(float lado){
       this.lado=lado;
  }
  
  
  //métodos operacionales
  public float calcularArea(){
      return this.lado*this.lado;
  }
  public float calcularPerimetro(){
      return this.lado*4;
  }
}