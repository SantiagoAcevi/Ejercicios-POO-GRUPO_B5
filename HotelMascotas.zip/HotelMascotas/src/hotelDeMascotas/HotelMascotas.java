/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hotelDeMascotas;

import controlador.*;
import java.util.ArrayList;
import modelo.*;
import vista.*;
/**
 *
 * @author roca
 */
public class HotelMascotas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Mascota> ListaMascotasTodos = new ArrayList<>();
        ArrayList<Reserva> ListaReserva = new ArrayList<>();
        
        vistaFormulario vista=new vistaFormulario();
        
        ControlAdministrador cntrlAdministrador = new ControlAdministrador(vista, ListaReserva);    
        ControlReserva cntrlReserva = new ControlReserva(ListaReserva, ListaMascotasTodos, vista, vista, cntrlAdministrador);
        ControlRegistrar cntrlRegistrar = new ControlRegistrar(vista, ListaMascotasTodos, cntrlReserva);
        
       
        vista.setVisible(true);
    }
    
}
