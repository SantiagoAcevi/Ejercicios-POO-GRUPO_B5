import java.util.List;

public class Enemigo extends Personaje
{
    public Enemigo(String nombre, String origen, List<Habilidad> habilidades, List<ObjetoMagico> equipo){
    super(nombre, origen, habilidades, equipo);
      
    }
}