

public class Escenario
{
   private Coordenada posicion;
   private String nombre;
   private String descripcion;
   
   public Escenario(Coordenada posicion,String nombre, String descripcion ){
       this.posicion=posicion;
       this.nombre=nombre;
       this.descripcion=descripcion;
   }
    
   //métodos getters
   public Coordenada getPosicion(){
       return this.posicion;
   }
   public String getNombre(){
       return this.nombre;
   }
   public String getDescripcion(){
       return this.descripcion;
   }
   //métodos setters
   public void setPosicion( Coordenada posicion){
        this.posicion=posicion;
   }
   public void setNombre(String nombre){
        this.nombre=nombre;
   }
   public void setDescripcion(String nombre){
        this.descripcion=descripcion;
   }
   
   
}