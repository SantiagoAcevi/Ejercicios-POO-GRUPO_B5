import java.util.List;
public abstract class Personaje
{
    protected String nombre; 
    protected String origen; 
    protected List<Habilidad> habilidades; 
    protected List<ObjetoMagico> equipo; 
    
    public Personaje(String nombre, String origen, List<Habilidad> habilidades, List<ObjetoMagico> equipo){
        this.nombre=nombre;
        this.origen=origen;
        this.habilidades=habilidades;
        this.equipo=equipo;
    }
    
    //métodos getters
    public String getNombre(){
        return this.nombre;
    }
    public String getOrigen(){
        return this.origen;
    }
    public List<Habilidad> getHabilidades(){
        return this.habilidades;
    }
    public List<ObjetoMagico> getEquipo(){
        return this.equipo;
    }
    //métodos setters
    public void setNombre(String nombre){
         this.nombre=nombre;
    }
    public void setOrigen(String origen){
         this.origen=origen;
    }
    public void setHabilidades(List<Habilidad> habilidades ){
         this.habilidades=habilidades;
    }
    public void setEquipo(List<ObjetoMagico> equipo){
         this.equipo=equipo;
    }
    //métodos operacionales
    public void combatir(Personaje clase){
        System.out.println("Wonder Woman lucha contra "+clase.getNombre());
    }
    
    public void interactuar(Personaje clase){
        System.out.println("Wonder Woman interactua con "+clase.getNombre());
    }
    
    public void utilizarObjeto(List<ObjetoMagico> equipo){
        for(ObjetoMagico elemento: equipo){
        System.out.println("Wonder Woman utiliza el objeto "+elemento.getNombre());

        }
    }
    
    public void interactuarEscenario(Escenario clase){
        System.out.println("Wonder Woman interactua con el escenario de "+clase.getNombre());

    }
    
    public void utilizarHabilidad(List<Habilidad> habilidades){
        for(Habilidad elemento: habilidades){
            System.out.println("Wonder Woman utilizara su habilidad "+elemento.getNombre());

        }
    }
    
    
}