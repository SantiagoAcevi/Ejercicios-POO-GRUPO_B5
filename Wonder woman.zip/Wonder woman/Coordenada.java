
public class Coordenada
{
    private double posicionx; 
    private double posiciony;
    
    public Coordenada(double posicionx,double posiciony ){
        this.posicionx=posicionx;
        this.posiciony=posiciony;
    }
    
    //métodos gettters
    public double getPosicionx(){
        return this.posicionx;
    }
    public double getPosiciony(){
        return this.posiciony;
    }
    //métodos setters
    public void setPosicionx(double posicionx){
        this.posicionx=posicionx;
    }
    public void setPosiciony(double posiciony){
        this.posiciony=posiciony;
    }
    //métodos operacionales
    public void crearCoordenada(){
        System.out.println("La coordenada es ("+posicionx+","+posiciony+")");
    }
    
    
    
}