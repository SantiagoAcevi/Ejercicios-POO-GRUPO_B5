import java.util.List;

public class Aliado extends Personaje
{
    public Aliado(String nombre, String origen, List<Habilidad> habilidades, List<ObjetoMagico> equipo){
    super(nombre, origen, habilidades, equipo);
      
    }
}