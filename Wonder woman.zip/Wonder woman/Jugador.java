

public class Jugador
{
 private String nombre;
 private int edad;
 private String id;

 public Jugador(String nombre,int edad, String id ){
     this.nombre=nombre;
     this.edad=edad;
     this.id=id;
 }
  
 //métodos getters
 public String getNombre(){
     return this.nombre;
 }
 public int getEdad(){
     return this.edad;
 }
 public String getId(){
     return this.id;
 }
 //métodos setters
 public void setNombre(String nombre){
     this.nombre=nombre;
 }
 public void setEdad(int edad){
     this.edad=edad;
 }
 public void setId(String id){
     this.id=id;
 }
 //métodos operacionales
 public void utilizarPersonaje(WonderWoman clase){
     System.out.println("Estas manejando al personaje "+clase.getNombre());
 }
 
 
 
 
 
 
}