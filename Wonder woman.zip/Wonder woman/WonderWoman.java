import java.util.List;

public class WonderWoman extends Personaje
{
  public WonderWoman(String nombre, String origen, List<Habilidad> habilidades, List<ObjetoMagico> equipo){
    super(nombre, origen, habilidades, equipo);
      
    }
}